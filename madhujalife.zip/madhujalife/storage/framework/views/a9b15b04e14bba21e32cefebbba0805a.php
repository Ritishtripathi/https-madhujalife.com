<!-- Footer Start -->
<div class="container-fluid footer py-5 wow fadeIn" data-wow-delay="0.2s">
    <div class="container py-5">
        <div class="row g-4 rounded mb-5" style="background: rgba(255, 255, 255, .03);">
            <div class="col-md-6 col-lg-6 col-xl-4">
                <div class="rounded p-4">
                    <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
                        style="width: 70px; height: 70px;">
                        <i class="fas fa-map-marker-alt fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h4 class="text-white">Address</h4>
                        <p class="mb-2">402, Raghulila Apt, Ambika Township Jivrajpark main road, Rajkot, Gujarat -
                            360005</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-4">
                <div class="rounded p-4">
                    <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
                        style="width: 70px; height: 70px;">
                        <i class="fas fa-envelope fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h4 class="text-white">Mail Us</h4>
                        <p class="mb-2">manish.kumar@madhujalife.com</p>
                    </div>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-4">
                <div class="rounded p-4">
                    <div class="rounded-circle bg-secondary d-flex align-items-center justify-content-center mb-4"
                        style="width: 70px; height: 70px;">
                        <i class="fa fa-phone-alt fa-2x text-primary"></i>
                    </div>
                    <div>
                        <h4 class="text-white">Call Us</h4>
                        <p class="mb-2">+91 9999916764</p>
                    </div>
                </div>
            </div>
            
        </div>
        <div class="row g-5">
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <div class="footer-item">
                        <h4 class="text-primary mb-4">Newsletter</h4>
                        <p class="mb-3">
                            Stay updated with the latest news, offers, and insights from <strong>Madhujalife</strong>.
                            Subscribe to our newsletter and be the first to know about new products
                        </p>
                        <div class="position-relative mx-auto rounded-pill">
                            <input class="form-control rounded-pill w-100 py-3 ps-4 pe-5" type="text"
                                placeholder="Enter your email">
                            <button type="button"
                                class="btn btn-primary rounded-pill position-absolute top-0 end-0 py-2 mt-2 me-2">SignUp</button>
                        </div>
                    </div>
                </div>  <div class="mt-3  d-inline-flex align-items-center">

    <!-- Facebook -->
    <a href="https://facebook.com" target="_blank" class="text-primary d-flex align-items-center justify-content-center me-3">
        <span class="rounded-circle btn-md-square border">
            <i class="fab fa-facebook-f"></i>
        </span>
    </a>

    <!-- Instagram -->
    <a href="https://instagram.com" target="_blank" class="text-primary d-flex align-items-center justify-content-center me-3">
        <span class="rounded-circle btn-md-square border">
            <i class="fab fa-instagram"></i>
        </span>
    </a>

    <!-- Twitter -->
    <a href="https://twitter.com" target="_blank" class="text-primary d-flex align-items-center justify-content-center me-3">
        <span class="rounded-circle btn-md-square border">
            <i class="fab fa-twitter"></i>
        </span>
    </a>

    <!-- LinkedIn -->
    <a href="https://linkedin.com" target="_blank" class="text-primary d-flex align-items-center justify-content-center">
        <span class="rounded-circle btn-md-square border">
            <i class="fab fa-linkedin-in"></i>
        </span>
    </a>

</div>

            </div>
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="text-primary mb-4">Customer Service</h4>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Contact Us</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Returns</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Site Map</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Testimonials</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> My Account</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Unsubscribe Notification</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="text-primary mb-4">Information</h4>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> About Us</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Delivery infomation</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Privacy Policy</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Terms & Conditions</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Warranty</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> FAQ</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Seller Login</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 col-xl-3">
                <div class="footer-item d-flex flex-column">
                    <h4 class="text-primary mb-4">Extras</h4>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Brands</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Gift Vouchers</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Affiliates</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Wishlist</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Order History</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                    <a href="#" class=""><i class="fas fa-angle-right me-2"></i> Track Your Order</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->


<!-- Copyright Start -->
<div class="container-fluid copyright py-4">
    <div class="container">
        <div class="row g-4 align-items-center">
            <div class="col-md-6 text-center text-md-start mb-md-0">
                <span class="text-white"><a href="#" class="border-bottom text-white"><i
                            class="fas fa-copyright text-light me-2"></i>Madhujalife </a>, All right
                    reserved.</span>
            </div>
            <div class="col-md-6 text-center text-md-end text-white">
                Designed & Develope By <a class="border-bottom text-white" href="www.spireweb.co.in"
                    target="_blank">SpireWeb.co.in</a>
            </div>
        </div>
    </div>
</div>
<!-- Copyright End -->


<!-- Back to Top -->
<a href="#" class="btn btn-primary btn-lg-square back-to-top"><i class="fa fa-arrow-up"></i></a>


<!-- JavaScript Libraries -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo e(asset('website/lib/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

<!-- Template Javascript -->
<script src="<?php echo e(asset('website/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\Users\Lenovo\Desktop\httpsmadhujalife.com\https-madhujalife.com\madhujalife\resources\views/website/layouts/footer.blade.php ENDPATH**/ ?>