@include('website.layouts.header')
@yield('content')
@include('website.layouts.footer')
@yield('footerscript')